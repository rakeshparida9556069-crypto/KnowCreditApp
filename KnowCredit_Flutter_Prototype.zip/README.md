# KnowCredit - Flutter Prototype

This is a minimal Flutter prototype for the KnowCredit app you requested.
It implements:
- Seller enters buyer PAN & amount
- Simulated OTP approval dialog
- Local storage of PAN profiles & transactions using SharedPreferences
- Profile view showing outstanding only
- Sellers can mark payments as received
- Basic reward points and KnowCredit score logic (prototype rules)

## How to build (on your PC)

1. Install Flutter: https://flutter.dev/docs/get-started/install
2. Install Android Studio or VS Code and Android SDK.
3. Open this project folder in your editor.
4. From terminal run:
   ```
   flutter pub get
   flutter run   # to run on emulator or connected device
   ```
5. To create release APK:
   ```
   flutter build apk --release
   ```
   Output APK: `build/app/outputs/flutter-apk/app-release.apk`

## Notes / Next steps for production
- Replace simulated OTP with real SMS OTP provider (MSG91 / Twilio).
- Add seller authentication (email/phone) and secure backend (Firebase / custom REST API).
- Replace SharedPreferences with a proper local DB (Hive/SQLite) and sync with server.
- Encrypt sensitive data and follow privacy/security laws (PAN handling).